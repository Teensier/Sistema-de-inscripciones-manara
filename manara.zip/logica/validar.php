<?php
require 'conexion.php';
$usuario = $_POST['uname'];
$clave = $_POST['psw'];

$consulta = "SELECT*FROM usuarios WHERE nombre = '$usuario' and contraseña ='$clave'";
$resusltado = mysqli_query($conexion,$consulta);
$fila = mysqli_num_rows($resusltado);
if($fila>0){
    header("location:home.html");
}
else{
    echo "error";
}
mysqli_free_result($resusltado);
mysqli_close($conexion);
